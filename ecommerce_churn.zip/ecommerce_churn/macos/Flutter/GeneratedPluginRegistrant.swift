//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import file_picker

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  FilePickerPlugin.register(with: registry.registrar(forPlugin: "FilePickerPlugin"))
}
