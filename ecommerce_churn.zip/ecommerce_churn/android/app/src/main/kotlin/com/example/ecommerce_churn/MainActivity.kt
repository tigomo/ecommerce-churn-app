package com.example.ecommerce_churn

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
