// ApiService: communicates with your FastAPI backend using Dio.
// Base URL: http://13.51.161.2:8000

import 'package:dio/dio.dart';
import '../models/prediction.dart';

class ApiService {
  static const String _baseUrl = 'http://13.51.161.2:8000';
  final Dio _dio;

  ApiService({Dio? dio})
      : _dio = dio ??
      Dio(BaseOptions(
        baseUrl: _baseUrl,
        connectTimeout: const Duration(seconds: 10),
        receiveTimeout: const Duration(seconds: 10),
        responseType: ResponseType.json,
      )) {
    // Uncomment during development to log requests/responses:
    // _dio.interceptors.add(LogInterceptor(requestBody: true, responseBody: true));
  }

  // GET /get_predictions with server-side pagination (limit, offset)
  Future<List<Prediction>> fetchGetPredictions({int limit = 50, int offset = 0}) async {
    try {
      final response = await _dio.get('/get_predictions', queryParameters: {'limit': limit, 'offset': offset});
      if (response.statusCode == 200) {
        final data = response.data;
        if (data is List) {
          return data.map((e) => Prediction.fromJson(e as Map<String, dynamic>)).toList();
        }
        // fallback if server wraps the list
        if (data is Map && data.containsKey('predictions')) {
          final list = data['predictions'];
          if (list is List) {
            return list.map((e) => Prediction.fromJson(e as Map<String, dynamic>)).toList();
          }
        }
        return [];
      }
      throw Exception('Status code ${response.statusCode}');
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  // GET /get_predictions_by_client/{client_id}
  Future<List<Prediction>> fetchGetPredictionsByClient(String clientId) async {
    try {
      final response = await _dio.get('/get_predictions_by_client/$clientId');
      if (response.statusCode == 200) {
        final data = response.data;
        if (data is List) {
          return data.map((e) => Prediction.fromJson(e as Map<String, dynamic>)).toList();
        }
        if (data is Map && data.containsKey('predictions')) {
          final list = data['predictions'];
          if (list is List) {
            return list.map((e) => Prediction.fromJson(e as Map<String, dynamic>)).toList();
          }
        }
        return [];
      }
      throw Exception('Status code ${response.statusCode}');
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  // GET /get_last_predictions?limit=10
  Future<List<Prediction>> fetchGetLastPredictions({int limit = 10}) async {
    try {
      final response = await _dio.get('/get_last_predictions', queryParameters: {'limit': limit});
      if (response.statusCode == 200) {
        final data = response.data;
        if (data is List) {
          return data.map((e) => Prediction.fromJson(e as Map<String, dynamic>)).toList();
        }
        if (data is Map && data.containsKey('predictions')) {
          final list = data['predictions'];
          if (list is List) {
            return list.map((e) => Prediction.fromJson(e as Map<String, dynamic>)).toList();
          }
        }
        return [];
      }
      throw Exception('Status code ${response.statusCode}');
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  // GET /get_predictions_stats
  Future<Map<String, dynamic>> fetchGetPredictionsStats() async {
    try {
      final response = await _dio.get('/get_predictions_stats');
      if (response.statusCode == 200) {
        if (response.data is Map) {
          return Map<String, dynamic>.from(response.data as Map);
        }
        return {};
      }
      throw Exception('Status code ${response.statusCode}');
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  // POST /predict_db (single prediction + save)
  Future<Prediction> postPredictDb(Map<String, dynamic> payload) async {
    try {
      final response = await _dio.post('/predict_db', data: payload);
      if (response.statusCode == 200 || response.statusCode == 201) {
        final d = response.data;
        if (d is Map<String, dynamic>) return Prediction.fromJson(d);
        // some endpoints return {"client_id":..., ...} without id field
        if (d is Map) return Prediction.fromJson(Map<String, dynamic>.from(d));
      }
      throw Exception('Status code ${response.statusCode}');
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  // POST /predict_batch_db (batch prediction + save)
  Future<List<Prediction>> postPredictBatchDb(List<Map<String, dynamic>> payloads) async {
    try {
      final response = await _dio.post('/predict_batch_db', data: payloads);
      if (response.statusCode == 200 || response.statusCode == 201) {
        final d = response.data;
        if (d is Map && d.containsKey('predictions')) {
          final list = d['predictions'];
          if (list is List) return list.map((e) => Prediction.fromJson(e as Map<String, dynamic>)).toList();
        } else if (d is List) {
          return d.map((e) => Prediction.fromJson(e as Map<String, dynamic>)).toList();
        }
      }
      throw Exception('Status code ${response.statusCode}');
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  // POST /predict_json_file_db (multipart file upload)
  Future<List<Prediction>> postPredictJsonFileDb({required List<int> fileBytes, required String filename}) async {
    try {
      final form = FormData.fromMap({
        'file': MultipartFile.fromBytes(fileBytes, filename: filename),
      });
      final response = await _dio.post('/predict_json_file_db', data: form);
      if (response.statusCode == 200 || response.statusCode == 201) {
        final d = response.data;
        if (d is Map && d.containsKey('predictions')) {
          final list = d['predictions'];
          if (list is List) return list.map((e) => Prediction.fromJson(e as Map<String, dynamic>)).toList();
        } else if (d is List) {
          return d.map((e) => Prediction.fromJson(e as Map<String, dynamic>)).toList();
        }
      }
      throw Exception('Status code ${response.statusCode}');
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  Exception _mapDioError(DioException e) {
    if (e.type == DioExceptionType.connectionTimeout || e.type == DioExceptionType.receiveTimeout || e.type == DioExceptionType.sendTimeout) {
      return Exception('Connection timeout, please try again later');
    }
    if (e.type == DioExceptionType.connectionError) {
      return Exception('Connection error, please try again later');
    }
    if (e.response != null) {
      final status = e.response?.statusCode;
      final message = e.response?.data != null ? e.response?.data.toString() : 'Server error';
      return Exception('Server error ($status): $message');
    }
    return Exception('Network error, please try again later');
  }
}