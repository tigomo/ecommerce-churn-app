/*
import '../models/models.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ApiService {
  static const String baseUrl = 'http://localhost:8000'; // Changez selon votre config

  static Future<List<Prediction>> getPredictions() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/get_predictions'));
      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        return data.map((json) => Prediction.fromJson(json)).toList();
      }
      throw Exception('Erreur lors du chargement des prédictions');
    } catch (e) {
      // Données de démo en cas d'erreur
      return [
        Prediction(id: 1, clientId: 'CL_001', churnProbability: 0.8542, confidenceScore: '85.42 %', predictionType: 'single', timestamp: DateTime.now().subtract(Duration(hours: 2))),
        Prediction(id: 2, clientId: 'CL_002', churnProbability: 0.2341, confidenceScore: '76.59 %', predictionType: 'batch', timestamp: DateTime.now().subtract(Duration(hours: 5))),
        Prediction(id: 3, clientId: 'CL_003', churnProbability: 0.6789, confidenceScore: '67.89 %', predictionType: 'single', timestamp: DateTime.now().subtract(Duration(hours: 8))),
        Prediction(id: 4, clientId: 'CL_004', churnProbability: 0.1234, confidenceScore: '87.66 %', predictionType: 'json_file', timestamp: DateTime.now().subtract(Duration(days: 1))),
        Prediction(id: 5, clientId: 'CL_005', churnProbability: 0.9876, confidenceScore: '98.76 %', predictionType: 'single', timestamp: DateTime.now().subtract(Duration(days: 1))),
      ];
    }
  }

  static Future<PredictionStats> getStats() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/get_predictions_stats'));
      if (response.statusCode == 200) {
        return PredictionStats.fromJson(json.decode(response.body));
      }
      throw Exception('Erreur lors du chargement des statistiques');
    } catch (e) {
      // Données de démo
      return PredictionStats(
        totalPredictions: 156,
        averageChurnProbability: 0.4523,
        predictionsByType: {'single': 89, 'batch': 34, 'json_file': 33},
      );
    }
  }
}*/
