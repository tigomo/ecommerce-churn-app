import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/prediction.dart';

class PredictionDetailScreen extends StatelessWidget {
  final Prediction prediction;
  const PredictionDetailScreen({Key? key, required this.prediction}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final dtFormat = DateFormat.yMd().add_jm();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Prediction Details'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          color: Theme.of(context).cardColor,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Client ID: ${prediction.clientId}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Row(children: [
                const Text('Churn Probability: ', style: TextStyle(fontWeight: FontWeight.w600)),
                Text(prediction.churnProbability.toStringAsFixed(4)),
              ]),
              const SizedBox(height: 8),
              Row(children: [
                const Text('Confidence: ', style: TextStyle(fontWeight: FontWeight.w600)),
                Text(prediction.confidenceScore),
              ]),
              const SizedBox(height: 8),
              Row(children: [
                const Text('Prediction Type: ', style: TextStyle(fontWeight: FontWeight.w600)),
                Text(prediction.predictionType ?? '-'),
              ]),
              const SizedBox(height: 8),
              Row(children: [
                const Text('Timestamp: ', style: TextStyle(fontWeight: FontWeight.w600)),
                Text(dtFormat.format(prediction.timestamp.toLocal())),
              ]),
              const SizedBox(height: 16),
              const Divider(),
              const SizedBox(height: 8),
              const Text('Raw JSON', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Expanded(
                child: SingleChildScrollView(
                  child: Text(
                    prediction.toJson().toString(),
                    style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                  ),
                ),
              )
            ]),
          ),
        ),
      ),
    );
  }
}