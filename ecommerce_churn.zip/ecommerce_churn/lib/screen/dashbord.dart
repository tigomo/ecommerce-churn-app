// Flutter screen: Ecomus-style Ecommerce Dashboard
//
// Usage:
// 1) Add dependency to pubspec.yaml:
//    dependencies:
//      flutter:
//        sdk: flutter
//      fl_chart: ^0.63.0
//
// 2) Place this file in lib/ and use EcomusDashboardScreen() as your home widget.
//
// This single-file screen implements:
// - Top AppBar with search and profile area
// - Left navigation sidebar (persistent on wide screens, drawer on small screens)
// - Tab navigation (Overview, Customers, Products)
// - KPI cards row (4 cards) with mini area/line indicators
// - Revenue bar chart and category pie chart (using fl_chart)
// - Recent orders list
// - Right-hand "Top sale" product list with thumbnails
//
// NOTE: This is a sample UI with static sample data. Replace sample data with your backend models.

import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class EcomusDashboardScreen extends StatefulWidget {
  const EcomusDashboardScreen({Key? key}) : super(key: key);

  @override
  State<EcomusDashboardScreen> createState() => _EcomusDashboardScreenState();
}

class _EcomusDashboardScreenState extends State<EcomusDashboardScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _overviewRange = 'Weekly';
  String _revenueRange = 'Yearly';
  String _promoRange = 'Weekly';

  final List<Map<String, String>> _recentOrders = [
    {'id': '#1001', 'date': '2025-09-01', 'amount': '\$150.00'},
    {'id': '#1002', 'date': '2025-08-30', 'amount': '\$250.00'},
    {'id': '#1003', 'date': '2025-08-28', 'amount': '\$80.00'},
    {'id': '#1004', 'date': '2025-08-25', 'amount': '\$420.00'},
  ];

  final List<Map<String, dynamic>> _topSales = [
    {
      'title': 'Neptune Tee',
      'price': '\$138',
      'sales': 952,
      'image': 'https://via.placeholder.com/64x64.png?text=N'
    },
    {
      'title': 'Ribbed Tank',
      'price': '\$108',
      'sales': 952,
      'image': 'https://via.placeholder.com/64x64.png?text=R'
    },
    {
      'title': 'Ribbed Modal',
      'price': '\$125',
      'sales': 902,
      'image': 'https://via.placeholder.com/64x64.png?text=M'
    },
    {
      'title': 'Oversized Moto',
      'price': '\$98',
      'sales': 882,
      'image': 'https://via.placeholder.com/64x64.png?text=O'
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  Widget _buildSidebar(BuildContext context) {
    final menuItems = [
      {'icon': Icons.home_outlined, 'label': 'Ecommerce'},
      {'icon': Icons.inventory_2_outlined, 'label': 'Product'},
      {'icon': Icons.layers_outlined, 'label': 'Category'},
      {'icon': Icons.tune_outlined, 'label': 'Attributes'},
      {'icon': Icons.shopping_bag_outlined, 'label': 'Order'},
      {'icon': Icons.people_outline, 'label': 'Users'},
      {'icon': Icons.storefront_outlined, 'label': 'Online Store'},
      {'icon': Icons.bar_chart_outlined, 'label': 'Report'},
      {'icon': Icons.settings_outlined, 'label': 'Setting'},
      {'icon': Icons.help_outline, 'label': 'FAQ'},
      {'icon': Icons.logout, 'label': 'Log Out'},
    ];

    return Container(
      width: 220,
      color: Colors.white,
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 6.0),
            child: Text(
              'ecomus',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
          ),
          const Divider(),
          Expanded(
            child: ListView.separated(
              itemCount: menuItems.length,
              separatorBuilder: (_, __) => const SizedBox(height: 4),
              itemBuilder: (context, index) {
                final item = menuItems[index];
                final isActive = index == 0;
                return ListTile(
                  dense: true,
                  leading: Icon(item['icon'] as IconData, color: isActive ? Colors.deepOrange : Colors.black54),
                  title: Text(
                    item['label'] as String,
                    style: TextStyle(
                      color: isActive ? Colors.deepOrange : Colors.black87,
                      fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
                    ),
                  ),
                  contentPadding: EdgeInsets.zero,
                  onTap: () {},
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildKpiCard({
    required String title,
    required String value,
    required String rangeLabel,
    required IconData icon,
    required Color color,
    required double changePercent,
    required List<double> miniData,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(14.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 20,
                backgroundColor: color.withOpacity(0.12),
                child: Icon(icon, color: color),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(title, style: const TextStyle(color: Colors.black54)),
                  const SizedBox(height: 4),
                  Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                ]),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Row(
                    children: [
                      Icon(
                        changePercent >= 0 ? Icons.trending_up : Icons.trending_down,
                        color: changePercent >= 0 ? Colors.green : Colors.red,
                        size: 16,
                      ),
                      const SizedBox(width: 4),
                      Text('${changePercent.abs().toStringAsFixed(2)}%', style: const TextStyle(fontSize: 12)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(rangeLabel, style: const TextStyle(color: Colors.black45, fontSize: 12)),
                ],
              )
            ],
          ),
          const SizedBox(height: 8),
          // Mini sparkline (simple custom painter using a small LineChart)
          SizedBox(
            height: 48,
            child: LineChart(
              LineChartData(
                gridData: FlGridData(show: false),
                titlesData: FlTitlesData(show: false),
                borderData: FlBorderData(show: false),
                lineTouchData: LineTouchData(enabled: false),
                minY: 0,
                maxY: miniData.reduce((a, b) => a > b ? a : b) * 1.2,
                lineBarsData: [
                  LineChartBarData(
                    spots: List.generate(miniData.length, (i) => FlSpot(i.toDouble(), miniData[i])),
                    isCurved: true,
                    color: color,
                    dotData: FlDotData(show: false),
                    belowBarData: BarAreaData(show: true, color: color.withOpacity(0.12)),
                    barWidth: 3,
                  ),
                ],
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _buildBarChartCard() {
    final barValues = [0.0, 120.0, 250.0, 200.0, 180.0, 220.0, 280.0];
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(
            children: [
              const Expanded(child: Text('Revenue', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
              DropdownButton<String>(
                value: _revenueRange,
                items: const [
                  DropdownMenuItem(value: 'Yearly', child: Text('Yearly')),
                  DropdownMenuItem(value: 'Monthly', child: Text('Monthly')),
                  DropdownMenuItem(value: 'Weekly', child: Text('Weekly')),
                ],
                onChanged: (v) => setState(() => _revenueRange = v ?? _revenueRange),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
                  Text('Revenue', style: TextStyle(color: Colors.orange)),
                  SizedBox(height: 4),
                ]),
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: const [
                Text('Order', style: TextStyle(color: Colors.purple)),
                SizedBox(height: 4),
              ]),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 220,
            child: BarChart(
              BarChartData(
                maxY: 320,
                alignment: BarChartAlignment.spaceAround,
                barGroups: List.generate(barValues.length, (i) {
                  return BarChartGroupData(
                    x: i,
                    barRods: [
                      BarChartRodData(
                        toY: barValues[i],
                        color: Colors.deepOrange,
                        width: 18,
                        borderRadius: BorderRadius.circular(6),
                      )
                    ],
                  );
                }),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(showTitles: true, reservedSize: 32),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        final labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'];
                        final idx = value.toInt();
                        return Text(idx >= 0 && idx < labels.length ? labels[idx] : '');
                      },
                      reservedSize: 30,
                    ),
                  ),
                  rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                ),
                gridData: FlGridData(show: true, drawVerticalLine: false),
                borderData: FlBorderData(show: false),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _buildPieChartCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(
            children: [
              const Expanded(child: Text('Promotional Sales', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
              DropdownButton<String>(
                value: _promoRange,
                items: const [
                  DropdownMenuItem(value: 'Weekly', child: Text('Weekly')),
                  DropdownMenuItem(value: 'Monthly', child: Text('Monthly')),
                ],
                onChanged: (v) => setState(() => _promoRange = v ?? _promoRange),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text('Visitors', style: TextStyle(color: Colors.black54)),
          const SizedBox(height: 6),
          Row(
            children: [
              const Text('7,802', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(width: 8),
              Row(children: const [Icon(Icons.trending_up, color: Colors.green, size: 16), Text('0.56%')])
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 180,
            child: Row(
              children: [
                Expanded(
                  flex: 1,
                  child: PieChart(PieChartData(
                    sections: [
                      PieChartSectionData(color: Colors.blue, value: 40, title: 'Electronics', radius: 48, titleStyle: const TextStyle(color: Colors.white, fontSize: 12)),
                      PieChartSectionData(color: Colors.orange, value: 30, title: 'Clothing', radius: 40, titleStyle: const TextStyle(color: Colors.white, fontSize: 12)),
                      PieChartSectionData(color: Colors.purple, value: 20, title: 'Home', radius: 36, titleStyle: const TextStyle(color: Colors.white, fontSize: 12)),
                      PieChartSectionData(color: Colors.red, value: 10, title: 'Other', radius: 32, titleStyle: const TextStyle(color: Colors.white, fontSize: 12)),
                    ],
                    sectionsSpace: 4,
                    centerSpaceRadius: 36,
                  )),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 1,
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    _legendDot(Colors.blue, 'Electronics'),
                    const SizedBox(height: 8),
                    _legendDot(Colors.orange, 'Clothing'),
                    const SizedBox(height: 8),
                    _legendDot(Colors.purple, 'Home'),
                    const SizedBox(height: 8),
                    _legendDot(Colors.red, 'Other'),
                  ]),
                )
              ],
            ),
          ),
        ]),
      ),
    );
  }

  Widget _legendDot(Color color, String label) {
    return Row(children: [
      Container(width: 12, height: 12, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(3))),
      const SizedBox(width: 8),
      Text(label),
    ]);
  }

  Widget _buildRecentOrdersCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Column(children: [
        const ListTile(title: Text('Recent Orders', style: TextStyle(fontWeight: FontWeight.bold))),
        ..._recentOrders.map((o) => ListTile(
          title: Text(o['id']!),
          subtitle: Text(o['date']!),
          trailing: Text(o['amount']!, style: const TextStyle(fontWeight: FontWeight.w600)),
        )),
      ]),
    );
  }

  Widget _buildTopSalesListCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Expanded(child: Text('Top sale', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
            DropdownButton<String>(
              value: _overviewRange,
              items: const [
                DropdownMenuItem(value: 'Weekly', child: Text('Weekly')),
                DropdownMenuItem(value: 'Monthly', child: Text('Monthly')),
              ],
              onChanged: (v) => setState(() => _overviewRange = v ?? _overviewRange),
            ),
          ]),
          const SizedBox(height: 8),
          ..._topSales.map((p) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: Row(children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(p['image'], width: 56, height: 56, fit: BoxFit.cover),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(p['title'], style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  Text(p['price'], style: const TextStyle(color: Colors.black54)),
                ]),
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text('${p['sales']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                const Text('Sales', style: TextStyle(color: Colors.black54)),
              ])
            ]),
          ))
        ]),
      ),
    );
  }

  Widget _buildMainContent(double width) {
    // Layout columns:
    // If width is wide, show KPI row, then a 2-column area: left (charts & recent orders) and right (top sales).
    // If narrow, show single column stacked.
    final isWide = width >= 1000;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // KPI cards
        Wrap(
          spacing: 16,
          runSpacing: 16,
          children: [
            SizedBox(
              width: isWide ? (width - 300) / 3 - 12 : width - 40,
              child: _buildKpiCard(
                title: 'Total Earnings',
                value: '\$334,945',
                rangeLabel: 'Weekly',
                icon: Icons.attach_money,
                color: Colors.green,
                changePercent: 1.56,
                miniData: [80, 120, 90, 150, 130],
              ),
            ),
            SizedBox(
              width: isWide ? (width - 300) / 3 - 12 : width - 40,
              child: _buildKpiCard(
                title: 'Total Orders',
                value: '2,802',
                rangeLabel: 'Monthly',
                icon: Icons.shopping_cart,
                color: Colors.deepOrange,
                changePercent: -1.56,
                miniData: [60, 90, 70, 120, 110],
              ),
            ),
            SizedBox(
              width: isWide ? (width - 300) / 3 - 12 : width - 40,
              child: _buildKpiCard(
                title: 'Customers',
                value: '4,945',
                rangeLabel: 'Yearly',
                icon: Icons.people,
                color: Colors.purple,
                changePercent: 1.56,
                miniData: [40, 80, 60, 100, 90],
              ),
            ),
            if (!isWide)
              const SizedBox(height: 8),
            // My Balance card (only if stacked show full width)
            if (!isWide)
              SizedBox(
                width: width - 40,
                child: _buildKpiCard(
                  title: 'My Balance',
                  value: '\$4,945',
                  rangeLabel: 'Yearly',
                  icon: Icons.account_balance_wallet_outlined,
                  color: Colors.blue,
                  changePercent: 1.56,
                  miniData: [60, 100, 80, 120, 110],
                ),
              ),
            if (isWide)
              SizedBox(
                width: (width - 300) / 3 - 12,
                child: _buildKpiCard(
                  title: 'My Balance',
                  value: '\$4,945',
                  rangeLabel: 'Yearly',
                  icon: Icons.account_balance_wallet_outlined,
                  color: Colors.blue,
                  changePercent: 1.56,
                  miniData: [60, 100, 80, 120, 110],
                ),
              ),
          ],
        ),
        const SizedBox(height: 20),
        // Tabs under AppBar area
        Container(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: TabBar(
            controller: _tabController,
            labelColor: Colors.black87,
            indicatorColor: Colors.deepOrange,
            unselectedLabelColor: Colors.black54,
            tabs: const [
              Tab(icon: Icon(Icons.dashboard), text: 'Overview'),
              Tab(icon: Icon(Icons.people), text: 'Customers'),
              Tab(icon: Icon(Icons.inventory), text: 'Products'),
            ],
          ),
        ),
        const SizedBox(height: 12),
        // Tab content
        SizedBox(
          height: isWide ? 820 : 1200,
          child: TabBarView(
            controller: _tabController,
            children: [
              // Overview tab
              isWide
                  ? Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                // left column (charts & recent orders)
                Expanded(
                  flex: 2,
                  child: Column(
                    children: [
                      _buildBarChartCard(),
                      const SizedBox(height: 16),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(child: _buildPieChartCard()),
                          const SizedBox(width: 16),
                          Expanded(child: _buildRecentOrdersCard()),
                        ],
                      )
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                // right column (top sales)
                SizedBox(width: 300, child: _buildTopSalesListCard()),
              ])
                  : Column(
                children: [
                  _buildBarChartCard(),
                  const SizedBox(height: 12),
                  _buildPieChartCard(),
                  const SizedBox(height: 12),
                  _buildRecentOrdersCard(),
                  const SizedBox(height: 12),
                  _buildTopSalesListCard(),
                ],
              ),
              // Customers tab
              Center(
                child: Text(
                  'Customer analytics and lists can be placed here.',
                  style: TextStyle(color: Colors.grey[700], fontSize: 16),
                ),
              ),
              // Products tab
              Center(
                child: Text(
                  'Top products, inventory and management UI goes here.',
                  style: TextStyle(color: Colors.grey[700], fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Drawer for small screens
      drawer: LayoutBuilder(builder: (context, constraints) {
        if (constraints.maxWidth < 1000) {
          return Drawer(child: _buildSidebar(context));
        } else {
          return SizedBox.shrink();
        }
      }),
      appBar: AppBar(
        elevation: 1,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        title: Row(
          children: [
            // Show a compact menu icon only on small screens
            LayoutBuilder(builder: (context, constraints) {
              if (constraints.maxWidth < 1000) {
                return Builder(
                  builder: (ctx) => IconButton(
                    icon: const Icon(Icons.menu),
                    onPressed: () => Scaffold.of(ctx).openDrawer(),
                  ),
                );
              }
              return const SizedBox.shrink();
            }),
            Expanded(
              child: Container(
                height: 40,
                margin: const EdgeInsets.only(left: 8, right: 12),
                child: TextField(
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search),
                    hintText: 'Search',
                    filled: true,
                    fillColor: Colors.grey[100],
                    contentPadding: const EdgeInsets.symmetric(vertical: 8),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
                  ),
                ),
              ),
            ),
            Row(children: [
              IconButton(
                onPressed: () {},
                icon: const Icon(Icons.language_outlined),
                color: Colors.black54,
              ),
              IconButton(
                onPressed: () {},
                icon: const Icon(Icons.notifications_outlined),
                color: Colors.black54,
              ),
              const SizedBox(width: 8),
              CircleAvatar(
                backgroundImage: NetworkImage('https://via.placeholder.com/48x48.png?text=K'),
              ),
              const SizedBox(width: 8),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
                Text('Kristin Watson', style: TextStyle(fontSize: 12)),
                Text('Sale Administrator', style: TextStyle(fontSize: 11, color: Colors.black54)),
              ])
            ]),
          ],
        ),
      ),
      body: LayoutBuilder(builder: (context, constraints) {
        final width = constraints.maxWidth;
        if (width >= 1000) {
          // desktop layout with persistent sidebar
          return Row(
            children: [
              _buildSidebar(context),
              Expanded(child: _buildMainContent(width)),
            ],
          );
        }
        // mobile / tablet layout
        return _buildMainContent(width);
      }),
    );
  }
}