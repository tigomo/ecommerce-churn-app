// Dashboard screen with provider, pagination, drawer actions, dialogs, table, chart and reliability charts.
// This file includes all dialog methods previously omitted (_showNewPredictionDialog, _showBatchPredictionDialog,
// _showUploadJsonDialog, _showGetByClientDialog, _showGetLastDialog, _showGetStatsDialog).
//
// Make sure the following files exist in your project:
// - lib/services/api_service.dart
// - lib/models/prediction.dart
// - lib/widgets/prediction_table.dart
// - lib/widgets/summary_cards.dart
// - lib/widgets/churn_chart.dart
// - lib/widgets/reliability_charts.dart
// - lib/screens/prediction_detail_screen.dart
//
// pubspec dependencies used: dio, provider, fl_chart, intl, file_picker

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:file_picker/file_picker.dart';


import '../models/prediction.dart';
import '../service/api_service.dart';
import '../widget/churn_chart.dart';
import '../widget/prediction_table.dart';
import '../widget/reliability_charts.dart';
import '../widget/summary_cards.dart';
import 'prediction_detail_screen.dart';

class PredictionsProvider extends ChangeNotifier {
  final ApiService api;
  PredictionsProvider(this.api);

  List<Prediction> _predictions = [];
  List<Prediction> get predictions => _predictions;

  bool _loading = false;
  bool get loading => _loading;

  String? _error;
  String? get error => _error;

  String _search = '';
  String get search => _search;

  // Pagination
  int pageSize = 25;
  int currentPage = 0; // zero-based
  int totalPredictions = 0;

  DateTime? lastPredictionTimestamp;
  int highRiskCount = 0;

  Map<String, dynamic>? lastStats;

  int get totalPages => pageSize == 0 ? 1 : ((totalPredictions + pageSize - 1) ~/ pageSize);

  List<Prediction> get filteredPredictions {
    if (_search.isEmpty) return _predictions;
    return _predictions.where((p) => p.clientId.toLowerCase().contains(_search.toLowerCase())).toList();
  }

  /// Load a specific page using /get_predictions?limit=..&offset=..
  Future<void> loadPage({int page = 0}) async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      currentPage = page;
      final list = await api.fetchGetPredictions(limit: pageSize, offset: page * pageSize);
      _predictions = list..sort((a, b) => b.timestamp.compareTo(a.timestamp));
      await _loadStatsFallback();
    } catch (e) {
      _error = e.toString();
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> loadAll() async => await loadPage(page: 0);

  Future<void> changePageSize(int size) async {
    pageSize = size;
    currentPage = 0;
    await loadPage(page: 0);
  }

  Future<void> loadByClient(String clientId) async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      final list = await api.fetchGetPredictionsByClient(clientId);
      _predictions = list..sort((a, b) => b.timestamp.compareTo(a.timestamp));
      totalPredictions = _predictions.length;
      lastPredictionTimestamp = _predictions.isNotEmpty ? _predictions.first.timestamp : null;
      highRiskCount = _predictions.where((p) => p.churnProbability > 0.7).length;
    } catch (e) {
      _error = e.toString();
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> loadLastPredictions({int limit = 10}) async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      final list = await api.fetchGetLastPredictions(limit: limit);
      _predictions = list..sort((a, b) => b.timestamp.compareTo(a.timestamp));
      totalPredictions = _predictions.length;
      lastPredictionTimestamp = _predictions.isNotEmpty ? _predictions.first.timestamp : null;
      highRiskCount = _predictions.where((p) => p.churnProbability > 0.7).length;
    } catch (e) {
      _error = e.toString();
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> loadStatsFromEndpoint() async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      final stats = await api.fetchGetPredictionsStats();
      lastStats = stats;
      totalPredictions = stats['total_predictions'] is int ? stats['total_predictions'] as int : totalPredictions;
      highRiskCount = stats['high_risk_count'] is int ? stats['high_risk_count'] as int : highRiskCount;
      lastPredictionTimestamp = stats['last_prediction_timestamp'] != null ? DateTime.parse(stats['last_prediction_timestamp'].toString()) : lastPredictionTimestamp;
    } catch (e) {
      _error = e.toString();
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> createPredictionDb({required String clientId, required Map<String, dynamic> features}) async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      final payload = {...features, 'client_id': clientId};
      await api.postPredictDb(payload);
      await loadPage(page: currentPage);
    } catch (e) {
      _error = e.toString();
      rethrow;
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> createBatchPredictionDb({required List<Map<String, dynamic>> payloads}) async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      await api.postPredictBatchDb(payloads);
      await loadPage(page: currentPage);
    } catch (e) {
      _error = e.toString();
      rethrow;
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> uploadJsonFileAndSave({required List<int> fileBytes, required String filename}) async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      await api.postPredictJsonFileDb(fileBytes: fileBytes, filename: filename);
      await loadPage(page: currentPage);
    } catch (e) {
      _error = e.toString();
      rethrow;
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> _loadStatsFallback() async {
    try {
      final stats = await api.fetchGetPredictionsStats();
      lastStats = stats;
      totalPredictions = stats['total_predictions'] is int ? stats['total_predictions'] as int : _predictions.length;
      highRiskCount = stats['high_risk_count'] is int ? stats['high_risk_count'] as int : _predictions.where((p) => p.churnProbability > 0.7).length;
      lastPredictionTimestamp = stats['last_prediction_timestamp'] != null ? DateTime.parse(stats['last_prediction_timestamp'].toString()) : (_predictions.isNotEmpty ? _predictions.first.timestamp : null);
    } catch (_) {
      totalPredictions = _predictions.length;
      highRiskCount = _predictions.where((p) => p.churnProbability > 0.7).length;
      lastPredictionTimestamp = _predictions.isNotEmpty ? _predictions.first.timestamp : null;
    }
  }

  Future<void> searchByClient(String q, {bool serverSide = false}) async {
    _search = q;
    notifyListeners();
    if (serverSide && q.isNotEmpty) {
      await loadByClient(q);
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late PredictionsProvider provider;
  final TextEditingController _searchController = TextEditingController();
  final DateFormat _dtFormat = DateFormat.yMd().add_jm();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      provider = Provider.of<PredictionsProvider>(context, listen: false);
      provider.loadPage(page: 0);
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // -----------------------
  // Dialogs implementations
  // -----------------------

  // Single prediction dialog (calls createPredictionDb)
  Future<void> _showNewPredictionDialog({bool saveToDbDefault = true}) async {
    final clientController = TextEditingController();
    final featuresController = TextEditingController(
        text:
        '{"Tenure":5,'
            '"PreferredLoginDevice":"Phone",'
            '"CityTier":2,"WarehouseToHome":12,'
            '"PreferredPaymentMode":"UPI",'
            '"Gender":"Female",'
            '"HourSpendOnApp":4,'
            '"NumberOfDeviceRegistered":3,'
            '"PreferedOrderCat":"Laptop & Accessory",'
            '"SatisfactionScore":3,'
            '"MaritalStatus":"Single",'
            '"NumberOfAddress":1,'
            '"Complain":0,'
            '"OrderAmountHikeFromlastYear":10,'
            '"CouponUsed":1,"OrderCount":2,'
            '"DaySinceLastOrder":7,'
            '"CashbackAmount":120}');
    bool saveToDb = saveToDbDefault;
    final formKey = GlobalKey<FormState>();

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        title: const Text('New Prediction (single)'),
        content: SingleChildScrollView(
          child: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: clientController,
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(labelText: 'Client ID'),
                  validator: (v) => (v == null || v.isEmpty) ? 'Enter client id' : null,
                ),
                const SizedBox(height: 8),
                TextFormField(
                  controller: featuresController,
                  style: const TextStyle(color: Colors.white70),
                  decoration: const InputDecoration(labelText: 'Features JSON'),
                  maxLines: 8,
                  validator: (v) {
                    if (v == null || v.isEmpty) return 'Provide features as JSON';
                    try {
                      jsonDecode(v);
                      return null;
                    } catch (_) {
                      return 'Invalid JSON';
                    }
                  },
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Text('Save to DB'),
                    const SizedBox(width: 8),
                    StatefulBuilder(builder: (ctx, setState) {
                      return Switch(
                        value: saveToDb,
                        onChanged: (v) => setState(() => saveToDb = v),
                      );
                    }),
                  ],
                )
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (!formKey.currentState!.validate()) return;
              try {
                final features = jsonDecode(featuresController.text) as Map<String, dynamic>;
                final clientId = clientController.text.trim();
                await provider.createPredictionDb(clientId: clientId, features: features);
                Navigator.of(ctx).pop();
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Prediction requested')));
              } catch (e) {
                Navigator.of(ctx).pop();
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: ${e.toString()}')));
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.deepOrange),
            child: const Text('Send'),
          ),
        ],
      ),
    );
  }

  // Batch JSON paste dialog -> POST /predict_batch_db
  Future<void> _showBatchPredictionDialog() async {
    final payloadController = TextEditingController(
        text:
        '[{"client_id":"CL_1","Tenure":5,"PreferredLoginDevice":"Phone","CityTier":2,"WarehouseToHome":12,"PreferredPaymentMode":"UPI","Gender":"Female","HourSpendOnApp":4,"NumberOfDeviceRegistered":3,"PreferedOrderCat":"Laptop & Accessory","SatisfactionScore":3,"MaritalStatus":"Single","NumberOfAddress":1,"Complain":0,"OrderAmountHikeFromlastYear":10,"CouponUsed":1,"OrderCount":2,"DaySinceLastOrder":7,"CashbackAmount":120}]');
    final formKey = GlobalKey<FormState>();

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        title: const Text('Batch Prediction (paste JSON array)'),
        content: SingleChildScrollView(
          child: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: payloadController,
                  style: const TextStyle(color: Colors.white70),
                  decoration: const InputDecoration(labelText: 'JSON array of feature objects'),
                  maxLines: 12,
                  validator: (v) {
                    if (v == null || v.isEmpty) return 'Provide JSON array';
                    try {
                      final parsed = jsonDecode(v);
                      if (parsed is List) return null;
                      return 'Expected JSON array';
                    } catch (_) {
                      return 'Invalid JSON';
                    }
                  },
                ),
                const SizedBox(height: 8),
                const Text('This will call POST /predict_batch_db and save results to DB', style: TextStyle(fontSize: 12))
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (!formKey.currentState!.validate()) return;
              try {
                final list = (jsonDecode(payloadController.text) as List).cast<Map<String, dynamic>>();
                await provider.createBatchPredictionDb(payloads: list);
                Navigator.of(ctx).pop();
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Batch prediction sent')));
              } catch (e) {
                Navigator.of(ctx).pop();
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: ${e.toString()}')));
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.deepOrange),
            child: const Text('Send Batch'),
          ),
        ],
      ),
    );
  }

  // File upload dialog -> POST /predict_json_file_db
  Future<void> _showUploadJsonDialog() async {
    try {
      final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json'], withData: true);
      if (result == null || result.files.isEmpty) return;
      final file = result.files.single;
      final bytes = file.bytes;
      final filename = file.name;
      if (bytes == null) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Unable to read file bytes')));
        return;
      }
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: Theme.of(context).cardColor,
          title: const Text('Upload JSON file and save'),
          content: Text('Upload ${filename} and save predictions to DB?'),
          actions: [
            TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Cancel')),
            ElevatedButton(onPressed: () => Navigator.of(ctx).pop(true), style: ElevatedButton.styleFrom(backgroundColor: Colors.deepOrange), child: const Text('Upload')),
          ],
        ),
      );
      if (confirmed != true) return;

      await provider.uploadJsonFileAndSave(fileBytes: bytes, filename: filename);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('File uploaded and predictions saved')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Upload failed: ${e.toString()}')));
    }
  }

  // Dialog to get predictions by client (calls loadByClient)
  Future<void> _showGetByClientDialog() async {
    final clientController = TextEditingController();
    final formKey = GlobalKey<FormState>();

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        title: const Text('Get Predictions by Client'),
        content: Form(
          key: formKey,
          child: TextFormField(
            controller: clientController,
            style: const TextStyle(color: Colors.white),
            decoration: const InputDecoration(labelText: 'Client ID'),
            validator: (v) => (v == null || v.isEmpty) ? 'Enter client id' : null,
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (!formKey.currentState!.validate()) return;
              final id = clientController.text.trim();
              Navigator.of(ctx).pop();
              try {
                await provider.loadByClient(id);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Loaded predictions for client')));
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: ${e.toString()}')));
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.deepOrange),
            child: const Text('Fetch'),
          ),
        ],
      ),
    );
  }

  // Dialog to fetch last N predictions
  Future<void> _showGetLastDialog() async {
    final limitController = TextEditingController(text: '10');
    final formKey = GlobalKey<FormState>();

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        title: const Text('Get Last Predictions'),
        content: Form(
          key: formKey,
          child: TextFormField(
            controller: limitController,
            style: const TextStyle(color: Colors.white),
            decoration: const InputDecoration(labelText: 'Limit'),
            keyboardType: TextInputType.number,
            validator: (v) {
              if (v == null || v.isEmpty) return 'Enter a number';
              final n = int.tryParse(v);
              if (n == null || n <= 0) return 'Enter a positive integer';
              return null;
            },
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (!formKey.currentState!.validate()) return;
              final n = int.parse(limitController.text.trim());
              Navigator.of(ctx).pop();
              try {
                await provider.loadLastPredictions(limit: n);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Loaded last predictions')));
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: ${e.toString()}')));
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.deepOrange),
            child: const Text('Fetch'),
          ),
        ],
      ),
    );
  }

  // Dialog to fetch stats and show them
  Future<void> _showGetStatsDialog() async {
    try {
      await provider.loadStatsFromEndpoint();
      final stats = provider.lastStats;
      if (stats == null) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No stats returned')));
        return;
      }

      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: Theme.of(context).cardColor,
          title: const Text('Predictions Stats'),
          content: SingleChildScrollView(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Total predictions: ${stats['total_predictions'] ?? provider.totalPredictions}'),
              const SizedBox(height: 8),
              Text('Average churn probability: ${stats['average_churn_probability'] ?? '-'}'),
              const SizedBox(height: 8),
              Text('High risk count (>0.7): ${stats['high_risk_count'] ?? provider.highRiskCount}'),
              const SizedBox(height: 8),
              Text('Last prediction timestamp: ${stats['last_prediction_timestamp'] ?? (provider.lastPredictionTimestamp?.toIso8601String() ?? 'N/A')}'),
              const SizedBox(height: 8),
              const SizedBox(height: 8),
              const Text('Predictions by type:', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              if (stats['predictions_by_type'] != null && stats['predictions_by_type'] is Map)
                ...((stats['predictions_by_type'] as Map).entries.map((e) => Text('${e.key}: ${e.value}'))),
            ]),
          ),
          actions: [TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Close'))],
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error fetching stats: ${e.toString()}')));
    }
  }

  // -----------------------
  // UI and helper methods
  // -----------------------

  // Navigate to details screen
  void _openDetails(Prediction p) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => PredictionDetailScreen(prediction: p)));
  }

  Widget _buildPaginationControls(PredictionsProvider prov) {
    final current = prov.currentPage + 1;
    final totalPages = prov.totalPages == 0 ? 1 : prov.totalPages;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(children: [
          IconButton(
            icon: const Icon(Icons.chevron_left),
            onPressed: prov.currentPage > 0 ? () => prov.loadPage(page: prov.currentPage - 1) : null,
          ),
          Text('Page $current / $totalPages'),
          IconButton(
            icon: const Icon(Icons.chevron_right),
            onPressed: (prov.currentPage + 1) < totalPages ? () => prov.loadPage(page: prov.currentPage + 1) : null,
          ),
        ]),
        Row(children: [
          const Text('Page size: '),
          const SizedBox(width: 8),
          DropdownButton<int>(
            value: prov.pageSize,
            items: const [
              DropdownMenuItem(value: 10, child: Text('10')),
              DropdownMenuItem(value: 25, child: Text('25')),
              DropdownMenuItem(value: 50, child: Text('50')),
              DropdownMenuItem(value: 100, child: Text('100')),
            ],
            onChanged: (v) {
              if (v != null) prov.changePageSize(v);
            },
          ),
          const SizedBox(width: 12),
          Text('Total: ${prov.totalPredictions}'),
        ])
      ],
    );
  }

  @override
  @override
  Widget build(BuildContext context) {
    return Consumer<PredictionsProvider>(
      builder: (context, prov, _) {
        return Scaffold(
          drawer: Drawer(
            child: Container(
              color: Theme.of(context).cardColor,
              padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Predictions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  ListTile(
                    leading: const Icon(Icons.playlist_add),
                    title: const Text('Predict (single & save)'),
                    onTap: () {
                      Navigator.of(context).pop();
                      _showNewPredictionDialog(saveToDbDefault: true);
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.file_copy),
                    title: const Text('Predict Batch (paste JSON) & save'),
                    onTap: () {
                      Navigator.of(context).pop();
                      _showBatchPredictionDialog();
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.upload_file),
                    title: const Text('Upload JSON file & save'),
                    onTap: () {
                      Navigator.of(context).pop();
                      _showUploadJsonDialog();
                    },
                  ),
                  const Divider(),
                  ListTile(
                    leading: const Icon(Icons.search),
                    title: const Text('Get Predictions by Client'),
                    onTap: () {
                      Navigator.of(context).pop();
                      _showGetByClientDialog();
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.history),
                    title: const Text('Get Last Predictions'),
                    onTap: () {
                      Navigator.of(context).pop();
                      _showGetLastDialog();
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.bar_chart),
                    title: const Text('Get Predictions Stats'),
                    onTap: () {
                      Navigator.of(context).pop();
                      _showGetStatsDialog();
                    },
                  ),
                  const Spacer(),
                  ListTile(
                    leading: const Icon(Icons.refresh),
                    title: const Text('Refresh predictions'),
                    onTap: () {
                      Navigator.of(context).pop();
                      prov.loadPage(page: prov.currentPage);
                    },
                  ),
                ],
              ),
            ),
          ),
          appBar: AppBar(
            title: const Text('Ecomus — Predictions Dashboard'),
            leading: Builder(
              builder: (context) {
                return IconButton(
                  icon: const Icon(Icons.menu),
                  onPressed: () => Scaffold.of(context).openDrawer(),
                );
              },
            ),
            actions: [
              IconButton(
                onPressed: () => _showNewPredictionDialog(),
                icon: const Icon(Icons.add),
                tooltip: 'New prediction',
              ),
              IconButton(
                onPressed: () => prov.loadPage(page: prov.currentPage),
                icon: const Icon(Icons.refresh),
                tooltip: 'Refresh',
              ),
            ],
          ),
          body: prov.loading
              ? const Center(child: CircularProgressIndicator())
              : prov.error != null
              ? Center(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(prov.error!, style: const TextStyle(color: Colors.white70)),
                  const SizedBox(height: 12),
                  ElevatedButton(onPressed: () => prov.loadPage(page: prov.currentPage), style: ElevatedButton.styleFrom(backgroundColor: Colors.deepOrange), child: const Text('Retry')),
                ],
              ),
            ),
          )
          // -> HERE: main scrollable content using ListView
              : ListView(
            padding: const EdgeInsets.all(16.0),
            children: [
              // Search bar row
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _searchController,
                      style: const TextStyle(color: Colors.white),
                      decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search by client id'),
                      onChanged: (v) => prov.searchByClient(v, serverSide: false),
                      onSubmitted: (v) => prov.searchByClient(v, serverSide: true),
                    ),
                  ),
                  const SizedBox(width: 12),
                  ElevatedButton.icon(
                    onPressed: () => prov.loadPage(page: 0),
                    icon: const Icon(Icons.refresh),
                    label: const Text('Refresh'),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.deepOrange),
                  )
                ],
              ),
              const SizedBox(height: 12),
              // Summary cards
              SummaryCards(
                totalPredictions: prov.totalPredictions,
                highRiskCount: prov.highRiskCount,
                lastPredictionTimestamp: prov.lastPredictionTimestamp,
              ),
              const SizedBox(height: 12),
              // Reliability charts (responsive)
              LayoutBuilder(builder: (context, constraints) {
                final isWide = constraints.maxWidth >= 900;
                if (isWide) {
                  return Row(
                    children: [
                      Expanded(child: TopClientsReliabilityChart(predictions: prov.predictions, ascending: true, title: 'Top clients fiables', topN: 6)),
                      const SizedBox(width: 12),
                      Expanded(child: TopClientsReliabilityChart(predictions: prov.predictions, ascending: false, title: 'Top clients à risque', topN: 6)),
                    ],
                  );
                } else {
                  return Column(
                    children: [
                      TopClientsReliabilityChart(predictions: prov.predictions, ascending: true, title: 'Top clients fiables', topN: 6),
                      const SizedBox(height: 12),
                      TopClientsReliabilityChart(predictions: prov.predictions, ascending: false, title: 'Top clients à risque', topN: 6),
                    ],
                  );
                }
              }),
              const SizedBox(height: 12),
              // Churn distribution chart
              SizedBox(height: 220, child: ChurnChart(predictions: prov.filteredPredictions)),
              const SizedBox(height: 12),
              // Pagination controls
              _buildPaginationControls(prov),
              const SizedBox(height: 8),
              // IMPORTANT: wrap the table in a SizedBox (fixed height) so ListView can scroll properly
              // adjust height (e.g. 480) as needed for your layout / screen size
              SizedBox(
                height: 520,
                child: PredictionTable(
                  predictions: prov.filteredPredictions,
                  onRowTap: (p) => _openDetails(p),
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }
}