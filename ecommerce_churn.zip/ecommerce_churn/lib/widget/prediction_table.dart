import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/prediction.dart';

typedef PredictionTapCallback = void Function(Prediction p);

class PredictionTable extends StatefulWidget {
  final List<Prediction> predictions;
  final PredictionTapCallback? onRowTap;
  const PredictionTable({Key? key, required this.predictions, this.onRowTap}) : super(key: key);

  @override
  State<PredictionTable> createState() => _PredictionTableState();
}

class _PredictionTableState extends State<PredictionTable> {
  bool _sortAscending = false;
  int? _sortColumnIndex = 1;
  final DateFormat _dtFormat = DateFormat.yMd().add_jm();

  List<Prediction> get items => widget.predictions;

  void _sort<T extends Comparable>(T Function(Prediction p) getField, int columnIndex, bool ascending) {
    setState(() {
      _sortColumnIndex = columnIndex;
      _sortAscending = ascending;
      items.sort((a, b) {
        final aVal = getField(a);
        final bVal = getField(b);
        return ascending ? Comparable.compare(aVal, bVal) : Comparable.compare(bVal, aVal);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Theme.of(context).cardColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Predictions', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          // Use LayoutBuilder to determine available height; fallback to 400 if unconstrained.
          LayoutBuilder(builder: (context, constraints) {
            final availableHeight = constraints.maxHeight.isFinite ? constraints.maxHeight : 400.0;
            return SizedBox(
              height: availableHeight,
              child: Scrollbar(
                thumbVisibility: true,
                child: SingleChildScrollView(
                  // Vertical scroll for rows
                  scrollDirection: Axis.vertical,
                  child: ConstrainedBox(
                    // Constrain width to at least full width so horizontal scroll behaves well
                    constraints: BoxConstraints(minWidth: MediaQuery.of(context).size.width),
                    child: SingleChildScrollView(
                      // Horizontal scroll for columns
                      scrollDirection: Axis.horizontal,
                      child: DataTable(
                        sortAscending: _sortAscending,
                        sortColumnIndex: _sortColumnIndex,
                        headingRowColor: MaterialStateProperty.all(Colors.grey.shade900),
                        dataRowHeight: 64,
                        columns: [
                          const DataColumn(label: Text('Client ID')),
                          DataColumn(label: const Text('Churn Probability'), numeric: true, onSort: (c, asc) => _sort<num>((d) => d.churnProbability, c, asc)),
                          const DataColumn(label: Text('Confidence')),
                          const DataColumn(label: Text('Prediction Type')),
                          const DataColumn(label: Text('Timestamp')),
                        ],
                        rows: items.map((p) {
                          final isHighRisk = p.churnProbability > 0.7;
                          return DataRow(
                            color: MaterialStateProperty.resolveWith((states) => isHighRisk ? Colors.red.withOpacity(0.06) : null),
                            onSelectChanged: (_) {
                              if (widget.onRowTap != null) widget.onRowTap!(p);
                            },
                            cells: [
                              DataCell(Text(p.clientId)),
                              DataCell(SizedBox(
                                width: 220,
                                child: Row(children: [
                                  Expanded(child: Text(p.churnProbability.toStringAsFixed(2))),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    flex: 3,
                                    child: LinearProgressIndicator(
                                      value: p.churnProbability.clamp(0.0, 1.0),
                                      backgroundColor: Colors.white10,
                                      color: p.churnProbability > 0.7 ? Colors.redAccent : Colors.blueAccent,
                                      minHeight: 10,
                                    ),
                                  ),
                                ]),
                              )),
                              DataCell(Text(p.confidenceScore)),
                              DataCell(Text(p.predictionType ?? '-')),
                              DataCell(Text(_dtFormat.format(p.timestamp.toLocal()))),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),
              ),
            );
          }),
        ]),
      ),
    );
  }
}