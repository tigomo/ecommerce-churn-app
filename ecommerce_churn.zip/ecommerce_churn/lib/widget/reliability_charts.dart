import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/prediction.dart';

/// Widget qui calcule la moyenne de churn par client et affiche un bar chart
/// - ascending=true -> affiche les clients les plus fiables (churn faible)
/// - ascending=false -> affiche les clients les moins fiables (churn élevé)
class TopClientsReliabilityChart extends StatelessWidget {
  final List<Prediction> predictions;
  final bool ascending;
  final int topN;
  final String title;

  const TopClientsReliabilityChart({
    Key? key,
    required this.predictions,
    required this.ascending,
    this.topN = 5,
    required this.title,
  }) : super(key: key);

  // Agrège par client_id et calcule la moyenne
  Map<String, double> _aggregateAverageByClient() {
    final Map<String, List<double>> map = {};
    for (final p in predictions) {
      final id = p.clientId;
      map.putIfAbsent(id, () => []).add(p.churnProbability);
    }
    final Map<String, double> avg = {};
    map.forEach((k, v) {
      avg[k] = v.reduce((a, b) => a + b) / v.length;
    });
    return avg;
  }

  @override
  Widget build(BuildContext context) {
    final avgMap = _aggregateAverageByClient();
    if (avgMap.isEmpty) {
      return Card(
        color: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            const Center(child: Text('No data', style: TextStyle(color: Colors.white70))),
          ]),
        ),
      );
    }

    // Convert to list and sort
    final entries = avgMap.entries.toList();
    entries.sort((a, b) => ascending ? a.value.compareTo(b.value) : b.value.compareTo(a.value));

    // take topN (or fewer)
    final topEntries = entries.take(topN).toList();

    // Build BarChart data
    final maxVal = topEntries.map((e) => e.value).fold<double>(0.0, (prev, el) => el > prev ? el : prev);
    final barGroups = <BarChartGroupData>[];
    for (var i = 0; i < topEntries.length; i++) {
      final val = topEntries[i].value;
      final color = ascending
          ? Colors.greenAccent.shade200 // reliable = green
          : Colors.redAccent.shade200; // unreliable = red
      barGroups.add(BarChartGroupData(
        x: i,
        barRods: [
          BarChartRodData(
            toY: val,
            width: 22,
            borderRadius: BorderRadius.circular(6),
            color: color,
          )
        ],
      ));
    }

    return Card(
      color: Theme.of(context).cardColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          SizedBox(
            height: 220,
            child: BarChart(
              BarChartData(
                maxY: (maxVal * 1.15).clamp(0.1, 1.0),
                alignment: BarChartAlignment.spaceAround,
                barGroups: barGroups,
                gridData: FlGridData(show: true),
                borderData: FlBorderData(show: false),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 36, getTitlesWidget: (value, meta) {
                    return Text(value.toStringAsFixed(2), style: const TextStyle(color: Colors.white70, fontSize: 10));
                  })),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 80,
                      getTitlesWidget: (value, meta) {
                        final idx = value.toInt();
                        if (idx < 0 || idx >= topEntries.length) return const SizedBox.shrink();
                        final label = topEntries[idx].key;
                        return SideTitleWidget(axisSide: meta.axisSide, space: 6, child: SizedBox(
                          width: 70,
                          child: Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11), overflow: TextOverflow.ellipsis, textAlign: TextAlign.center),
                        ));
                      },
                    ),
                  ),
                  rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          // Legend
          Row(
            children: [
              Container(width: 12, height: 12, color: ascending ? Colors.greenAccent.shade200 : Colors.redAccent.shade200),
              const SizedBox(width: 8),
              Text(ascending ? 'Clients les plus fiables (churn faible)' : 'Clients les moins fiables (churn élevé)', style: const TextStyle(color: Colors.white70)),
            ],
          ),
        ]),
      ),
    );
  }
}