import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/prediction.dart';

class ChurnChart extends StatelessWidget {
  final List<Prediction> predictions;
  final int bins;

  const ChurnChart({Key? key, required this.predictions, this.bins = 10}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final counts = List<int>.filled(bins, 0);
    for (final p in predictions) {
      final val = p.churnProbability.clamp(0.0, 1.0);
      final idx = ((val * (bins - 1)).round()).clamp(0, bins - 1);
      counts[idx]++;
    }

    final maxCount = counts.isNotEmpty ? counts.reduce((a, b) => a > b ? a : b).toDouble() : 1.0;

    return Card(
      color: Theme.of(context).cardColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Churn Probability Distribution', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Expanded(
            child: BarChart(BarChartData(
              maxY: (maxCount * 1.2).clamp(1.0, double.infinity),
              alignment: BarChartAlignment.spaceAround,
              barGroups: List.generate(bins, (i) {
                final toY = counts[i].toDouble();
                return BarChartGroupData(x: i, barRods: [BarChartRodData(toY: toY, color: i >= (bins * 0.7) ? Colors.redAccent : Colors.blueAccent, width: 12, borderRadius: BorderRadius.circular(6))]);
              }),
              titlesData: FlTitlesData(
                leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 28)),
                bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, getTitlesWidget: (val, meta) {
                  final idx = val.toInt();
                  if (idx < 0 || idx >= bins) return const Text('');
                  final low = (idx / bins);
                  final high = ((idx + 1) / bins);
                  return Text('${low.toStringAsFixed(1)}-${high.toStringAsFixed(1)}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 10));
                }, reservedSize: 56)),
                rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
              ),
              gridData: FlGridData(show: true),
              borderData: FlBorderData(show: false),
            )),
          ),
        ]),
      ),
    );
  }
}