import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/prediction.dart';

/// Scatter plot: churn_probability (y) vs confidence (x)
/// confidence_score expected like "93.2 %" -> parsed to 93.2
class ChurnConfidenceScatter extends StatelessWidget {
  final List<Prediction> predictions;
  final double pointSize;

  const ChurnConfidenceScatter({Key? key, required this.predictions, this.pointSize = 6}) : super(key: key);

  double _parseConfidence(String s) {
    try {
      final cleaned = s.replaceAll('%', '').trim();
      return double.tryParse(cleaned) ?? 0.0;
    } catch (_) {
      return 0.0;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (predictions.isEmpty) {
      return Card(
        color: Theme.of(context).cardColor,
        child: SizedBox(height: 220, child: Center(child: Text('No data', style: TextStyle(color: Colors.white70)))),
      );
    }

    final spots = <ScatterSpot>[];
    for (final p in predictions) {
      final conf = _parseConfidence(p.confidenceScore);
      final x = conf; // 0-100
      final y = (p.churnProbability.clamp(0.0, 1.0) * 100); // scale to 0-100 for axes consistency
      final color = p.churnProbability > 0.7 ? Colors.redAccent : Colors.greenAccent;
      spots.add(ScatterSpot(x, y, color: color, radius: pointSize));
    }

    return Card(
      color: Theme.of(context).cardColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Churn vs Confidence', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          SizedBox(
            height: 220,
            child: ScatterChart(ScatterChartData(
              scatterSpots: spots,
              minX: 0,
              maxX: 100,
              minY: 0,
              maxY: 100,
              gridData: FlGridData(show: true),
              titlesData: FlTitlesData(
                leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 32, getTitlesWidget: (v, meta) {
                  return Text((v / 100).toStringAsFixed(2), style: const TextStyle(color: Colors.white70, fontSize: 10));
                })),
                bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 36, getTitlesWidget: (v, meta) {
                  return Text('${v.toInt()}%', style: const TextStyle(color: Colors.white70, fontSize: 10));
                })),
                rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
              ),
              borderData: FlBorderData(show: false),
              scatterTouchData: ScatterTouchData(enabled: true, handleBuiltInTouches: true, touchTooltipData: ScatterTouchTooltipData(getTooltipItems: (spots) {
                return spots.map((s) {
                  final p = predictions[spots.indexOf(s)];
                  final conf = _parseConfidence(p.confidenceScore);
                  return ScatterTooltipItem('client: ${p.clientId}\nconf: ${conf.toStringAsFixed(1)}%\nchurn: ${p.churnProbability.toStringAsFixed(3)}', const TextStyle(color: Colors.white));
                }).toList();
              })),
            )),
          ),
        ]),
      ),
    );
  }
}