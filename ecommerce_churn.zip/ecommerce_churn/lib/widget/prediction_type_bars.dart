import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/prediction.dart';

class PredictionTypeBars extends StatelessWidget {
  final List<Prediction> predictions;
  final double height;

  const PredictionTypeBars({Key? key, required this.predictions, this.height = 160}) : super(key: key);

  Map<String, int> _countByType() {
    final Map<String, int> m = {
      'single': 0,
      'batch': 0,
      'json_file': 0,
    };

    for (final p in predictions) {
      final t = (p.predictionType ?? '').toString().toLowerCase();
      if (t.contains('single') || t == 'predict' || t == 'predict_db') {
        m['single'] = m['single']! + 1;
      } else if (t.contains('batch') || t == 'predict_batch' || t == 'predict_batch_db') {
        m['batch'] = m['batch']! + 1;
      } else if (t.contains('json') || t == 'json_file' || t == 'predict_json_file' || t == 'predict_json_file_db') {
        m['json_file'] = m['json_file']! + 1;
      } else {
        // If unknown, attempt to deduce from prediction_type string tokens
        if (t.isEmpty) {
          // try to use clientId or other heuristics - skip
        } else {
          // fallback: consider unknown as json_file if contains 'json', else single
          if (t.contains('json')) {
            m['json_file'] = m['json_file']! + 1;
          } else {
            m['single'] = m['single']! + 1;
          }
        }
      }
    }
    return m;
  }

  @override
  Widget build(BuildContext context) {
    final counts = _countByType();
    final values = [counts['single']!.toDouble(), counts['batch']!.toDouble(), counts['json_file']!.toDouble()];
    final labels = ['Single', 'Batch', 'JSON File'];
    final colors = [Colors.blueAccent, Colors.orangeAccent, Colors.purpleAccent];

    final maxVal = values.isNotEmpty ? (values.reduce((a, b) => a > b ? a : b)) : 1.0;
    final maxY = (maxVal * 1.2).clamp(1.0, double.infinity);

    // Build bar groups
    final barGroups = List.generate(3, (i) {
      return BarChartGroupData(
        x: i,
        barRods: [
          BarChartRodData(toY: values[i], color: colors[i], width: 28, borderRadius: BorderRadius.circular(6)),
        ],
      );
    });

    return Card(
      color: Theme.of(context).cardColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: SizedBox(
          height: height,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Predictions by Type (count)', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Expanded(
              child: Row(
                children: [
                  Expanded(
                    child: BarChart(
                      BarChartData(
                        maxY: maxY,
                        minY: 0,
                        alignment: BarChartAlignment.spaceAround,
                        barGroups: barGroups,
                        titlesData: FlTitlesData(
                          leftTitles: AxisTitles(
                            sideTitles: SideTitles(showTitles: true, reservedSize: 36, getTitlesWidget: (v, meta) {
                              // show integer ticks
                              if (v % 1 != 0) return const SizedBox.shrink();
                              return Text(v.toInt().toString(), style: const TextStyle(fontSize: 10));
                            }),
                          ),
                          bottomTitles: AxisTitles(
                            sideTitles: SideTitles(showTitles: true, getTitlesWidget: (v, meta) {
                              final idx = v.toInt();
                              if (idx < 0 || idx >= labels.length) return const SizedBox.shrink();
                              return SideTitleWidget(
                                axisSide: meta.axisSide,
                                child: Text(labels[idx], style: const TextStyle(fontSize: 12)),
                              );
                            }),
                          ),
                          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        ),
                        gridData: FlGridData(show: true),
                        borderData: FlBorderData(show: false),
                        barTouchData: BarTouchData(enabled: true),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  // Legend + values
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: List.generate(labels.length, (i) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6.0),
                        child: Row(
                          children: [
                            Container(width: 12, height: 12, decoration: BoxDecoration(color: colors[i], borderRadius: BorderRadius.circular(3))),
                            const SizedBox(width: 8),
                            Text(labels[i]),
                            const SizedBox(width: 8),
                            Text(counts[['single', 'batch', 'json_file'][i]]!.toString(), style: const TextStyle(fontWeight: FontWeight.bold)),
                          ],
                        ),
                      );
                    }),
                  )
                ],
              ),
            ),
          ]),
        ),
      ),
    );
  }
}