import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/prediction.dart';

class TopClientsBar extends StatelessWidget {
  final List<Prediction> predictions;
  final int topN;

  const TopClientsBar({Key? key, required this.predictions, this.topN = 8}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (predictions.isEmpty) {
      return Card(
        color: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: SizedBox(height: 160, child: Center(child: Text('No data', style: TextStyle(color: Colors.white70)))),
      );
    }

    // pour chaque client, prendre la dernière prédiction et trier par churn_probability
    final Map<String, Prediction> latestByClient = {};
    for (final p in predictions) {
      final key = p.clientId;
      final exist = latestByClient[key];
      if (exist == null || p.timestamp.isAfter(exist.timestamp)) latestByClient[key] = p;
    }

    final items = latestByClient.values.toList();
    items.sort((a, b) => b.churnProbability.compareTo(a.churnProbability));
    final topItems = items.take(topN).toList();
    final maxVal = topItems.map((e) => e.churnProbability).fold<double>(0, (prev, el) => el > prev ? el : prev);

    return Card(
      color: Theme.of(context).cardColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Top Clients by Churn', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          SizedBox(
            height: 160,
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: (maxVal * 1.15).clamp(0.5, 1.0),
                barGroups: List.generate(topItems.length, (i) {
                  final p = topItems[i];
                  return BarChartGroupData(
                    x: i,
                    barRods: [
                      BarChartRodData(
                        toY: p.churnProbability,
                        color: p.churnProbability > 0.7 ? Colors.redAccent : Colors.blueAccent,
                        width: 12,
                        borderRadius: BorderRadius.circular(6),
                      )
                    ],
                  );
                }),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 28)),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (val, meta) {
                        final idx = val.toInt();
                        if (idx < 0 || idx >= topItems.length) return const Text('');
                        final label = topItems[idx].clientId;
                        return SideTitleWidget(child: Text(label, style: const TextStyle(fontSize: 10)), axisSide: meta.axisSide);
                      },
                      reservedSize: 60,
                    ),
                  ),
                  rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                ),
                gridData: FlGridData(show: true),
                borderData: FlBorderData(show: false),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}