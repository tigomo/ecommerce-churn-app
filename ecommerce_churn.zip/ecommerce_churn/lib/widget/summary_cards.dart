import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class SummaryCards extends StatelessWidget {
  final int totalPredictions;
  final int highRiskCount;
  final DateTime? lastPredictionTimestamp;

  const SummaryCards({
    Key? key,
    required this.totalPredictions,
    required this.highRiskCount,
    required this.lastPredictionTimestamp,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final dtFormat = DateFormat.yMd().add_jm();
    Widget buildCard(String title, Widget child) {
      return Expanded(
          child: Card(
            color: Theme.of(context).cardColor,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: Colors.white70)), const SizedBox(height: 8), child])),
          ));
      }

    return Row(
      children: [
        buildCard('Total Predictions', Text('$totalPredictions', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        const SizedBox(width: 12),
        buildCard('High Risk (churn > 0.7)', Text('$highRiskCount', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.redAccent))),
        const SizedBox(width: 12),
        buildCard('Last Prediction', Text(lastPredictionTimestamp != null ? dtFormat.format(lastPredictionTimestamp!.toLocal()) : 'No data')),
      ],
    );
  }
}