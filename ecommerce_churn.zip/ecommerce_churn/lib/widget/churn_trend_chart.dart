import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../models/prediction.dart';

class ChurnTrendChart extends StatelessWidget {
  final List<Prediction> predictions;
  final int days; // nombre de jours à afficher (derniers n jours)

  const ChurnTrendChart({Key? key, required this.predictions, this.days = 14}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Grouper par jour (yyyy-MM-dd) et calculer la moyenne
    final now = DateTime.now().toUtc();
    final Map<String, List<double>> map = {};
    for (final p in predictions) {
      final d = p.timestamp.toUtc();
      final key = DateFormat('yyyy-MM-dd').format(d);
      map.putIfAbsent(key, () => []).add(p.churnProbability);
    }

    // Construire la liste des jours (dernier 'days' jours)
    final List<DateTime> daysList = List.generate(days, (i) => DateTime.utc(now.year, now.month, now.day).subtract(Duration(days: days - 1 - i)));
    final List<double> averages = daysList.map((dt) {
      final k = DateFormat('yyyy-MM-dd').format(dt);
      final values = map[k];
      if (values == null || values.isEmpty) return 0.0;
      return values.reduce((a, b) => a + b) / values.length;
    }).toList();

    final spots = List.generate(averages.length, (i) => FlSpot(i.toDouble(), averages[i]));

    final maxY = (averages.isEmpty ? 1.0 : (averages.reduce((a, b) => a > b ? a : b) * 1.2)).clamp(0.5, 1.0);

    return Card(
      color: Theme.of(context).cardColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Churn Trend (avg per day)', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          SizedBox(
            height: 160,
            child: LineChart(
              LineChartData(
                minX: 0,
                maxX: (spots.isEmpty ? 1 : spots.last.x),
                minY: 0,
                maxY: maxY,
                gridData: FlGridData(show: true),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 36)),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      interval: (spots.length <= 6) ? 1 : (spots.length / 6),
                      getTitlesWidget: (v, meta) {
                        final idx = v.toInt();
                        if (idx < 0 || idx >= daysList.length) return const Text('');
                        final label = DateFormat('MM-dd').format(daysList[idx].toLocal());
                        return SideTitleWidget(child: Text(label, style: const TextStyle(fontSize: 10)), axisSide: meta.axisSide);
                      },
                    ),
                  ),
                  topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                ),
                lineBarsData: [
                  LineChartBarData(
                    spots: spots,
                    isCurved: true,
                    color: Colors.orangeAccent,
                    barWidth: 3,
                    dotData: FlDotData(show: false),
                    belowBarData: BarAreaData(show: true, color: Colors.orangeAccent.withOpacity(0.12)),
                  ),
                ],
                borderData: FlBorderData(show: false),
                lineTouchData: LineTouchData(enabled: true),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}