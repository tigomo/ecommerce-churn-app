// Prediction model matching backend schema
// {
//   "id": int,
//   "client_id": string,
//   "churn_probability": float,
//   "confidence_score": string,
//   "prediction_type": string,
//   "timestamp": datetime
// }

class Prediction {
  final int? id;
  final String clientId;
  final double churnProbability;
  final String confidenceScore;
  final String? predictionType;
  final DateTime timestamp;

  Prediction({
    required this.id,
    required this.clientId,
    required this.churnProbability,
    required this.confidenceScore,
    required this.predictionType,
    required this.timestamp,
  });

  factory Prediction.fromJson(Map<String, dynamic> json) {
    // Parse timestamp robustly: can be ISO string or already DateTime
    DateTime ts;
    final rawTs = json['timestamp'];
    if (rawTs == null) {
      ts = DateTime.now().toUtc();
    } else if (rawTs is String) {
      ts = DateTime.parse(rawTs).toUtc();
    } else if (rawTs is DateTime) {
      ts = rawTs.toUtc();
    } else {
      // If server returns weird type, try toString parse
      ts = DateTime.tryParse(rawTs.toString())?.toUtc() ?? DateTime.now().toUtc();
    }

    final churnVal = json['churn_probability'];
    double churn = 0.0;
    if (churnVal is num) churn = churnVal.toDouble();
    else if (churnVal is String) churn = double.tryParse(churnVal) ?? 0.0;

    return Prediction(
      id: json['id'] != null ? (json['id'] is int ? json['id'] as int : int.tryParse(json['id'].toString())) : null,
      clientId: json['client_id']?.toString() ?? '',
      churnProbability: churn,
      confidenceScore: json['confidence_score']?.toString() ?? '',
      predictionType: json['prediction_type']?.toString(),
      timestamp: ts,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'client_id': clientId,
    'churn_probability': churnProbability,
    'confidence_score': confidenceScore,
    'prediction_type': predictionType,
    'timestamp': timestamp.toIso8601String(),
  };
}